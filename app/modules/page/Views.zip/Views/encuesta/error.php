<div class="container">
	<div class="col-md-12 text-center">
		<div class="gracias_encuesta"><h3><?php echo $this->error; ?></h3></div>
	</div>
</div>