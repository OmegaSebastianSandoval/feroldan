<div class="container">
	<div class="col-md-12 text-center">
		<div class="gracias_encuesta"><h3>Usted ya llenó esta encuesta</h3></div>
	</div>
</div>