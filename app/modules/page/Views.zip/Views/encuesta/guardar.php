<div class="container">
	<div class="col-md-12 text-center">
		<div class="gracias_encuesta"><h3>Gracias por enviar la encuesta</h3></div>
	</div>
</div>