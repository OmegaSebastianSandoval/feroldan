<!-- <div class="titulo-internas" style="background-image:url(/skins/page/images/fondo2.png)">
    <div align="center"><h2>Ahorros</h2></div>
</div> -->

<div class="titulo-internas" style="background-image:url(/skins/page/images/fondo2.png)">
    <div class="container">
        <div align="left">
            <h2 class=" ml-4">Ahorros</h2>
        </div>

    </div>
</div>
<?php echo $this->ahorro; ?>