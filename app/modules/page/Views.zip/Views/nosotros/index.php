<div class="titulo-internas" style="background-image:url(/skins/page/images/fondo2.png)">
    <div class="container">
        <div align="left">
            <h2 class=" ml-4">Acerca de Nosotros</h2>
        </div>

    </div>
</div>
<?php echo $this->nosotros; ?>