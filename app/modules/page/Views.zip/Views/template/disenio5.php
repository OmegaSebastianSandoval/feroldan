<div class="servicios   servicios_<?php echo $contenido->contenido_padre ?>">
    <div class="imagen" align="center"><a href="<?php echo $contenido->contenido_enlace ?>"><img src="/images/<?php echo $contenido->contenido_imagen ?>" alt=""></div>
    <div class="pl-4 pr-4"><?php echo $contenido->contenido_descripcion ?></div>
    </a>
    
    <!--   <?php if ($contenido->contenido_enlace) { ?>
        <div align="center"><a href="<?php echo $contenido->contenido_enlace ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Ver más</a></div>
    <?php } ?> -->

</div>